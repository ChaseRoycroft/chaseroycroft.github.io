---
layout: post
section-type: post
title: Blog relaunch
date: '2016-02-09T12:29:00.003+02:00'
author: Jørn Ølmheim
category: tech
tags:
---
In 2016 I have decided to relaunch this old blog on a new platform. I'm now using Jekyll and ruby to build a static
site and host it on GitHub Pages.

I plan to spend some time sharing ideas in between my other activities, so hopefully there will be more to come.

Stay tuned.
