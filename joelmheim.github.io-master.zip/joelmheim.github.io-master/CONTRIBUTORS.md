In alphabetical order:

  1. Fatima Villanueva (Kaira) <fzf.villanueva@gmail.com>
  2. Jorge Arias <mail@jorgearias.cl>
  3. Jose Zamudio <jose.zamudiobarrera@postgrad.manchester.ac.uk>
  4. Kartik Arora <chipset95@yahoo.co.in>
  5. Marcus Eisele <marcus.eisele@gmail.com>
  6. Nathan Jaremkio <njaremko@gmail.com>
  7. Panos Sakkos <panos.sakkos@protonmail.com>
  8. Prashant Solanki <prs.solanki@live.com>
  9. Sergey Lysenko <soulwish.ls@gmail.com>
