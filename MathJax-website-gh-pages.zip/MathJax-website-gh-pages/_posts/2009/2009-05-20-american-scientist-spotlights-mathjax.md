---
layout: post
title: American Scientist Spotlights MathJax
date: 2009-05-20 08:38:48.000000000 +02:00
categories:
- News
tags: []
status: publish
type: post
published: true
meta:
  _edit_last: '3'
author:
  login: robertm
  email: stevenp@dessci.com
  display_name: Robert Miner
  first_name: Robert
  last_name: Miner
---

MathJax was featured in [Writing Math on the Web](http://www.americanscientist.org/issues/pub/2009/3/writing-math-on-the-web/1), which appeared in the May-June 2009 issue of [American Scientist](http://www.americanscientist.org/) magazine.  In the article, author Brian Hayes reviews past attempts to solve the problems of publishing mathematics to the web, both server-side and client-side, and including both TeX-based and MathML-based approaches.  Hayes interviews lead MathJax programmer Davide Cervone, and speculates about the future impact of Ajax-based solution just as MathJax.