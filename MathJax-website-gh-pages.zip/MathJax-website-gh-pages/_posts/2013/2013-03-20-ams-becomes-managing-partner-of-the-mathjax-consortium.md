---
layout: post
title: AMS becomes managing partner of the MathJax Consortium
date: 2013-03-20 10:11:11.000000000 +01:00
categories:
- News
tags: []
status: publish
type: post
published: true
meta:
  _rawhtml_settings: '0,0,0,0'
  _edit_last: '12'
  _cws_is_markdown: '2'
  _cws_is_markdown_gmt: '2013-03-20 18:11:11'
  dsq_thread_id: '1152384816'
author:
  login: PeterK
  email: info@mathjax.org
  display_name: Peter Krautzberger
  first_name: Peter
  last_name: Krautzberger
---

As of March 2013, the [MathJax Consortium](http://www.mathjax.org) has appointed the American Mathematical Society as its managing partner. This organizational change means that the AMS will be handling the administrative affairs of the MathJax project.

The MathJax Consortium and its team are grateful for the support provided by its previous managing partner, Design Science, and look forward to continuing the success of the MathJax project.