---
layout: post
title: IBM becomes a MathJax Supporter
date: 2016-09-16
author: Peter Krautzberger
categories:
- News
---

[IBM](http://www.ibm.com) is giving the MathJax project a boost by joining our sponsorship program as [MathJax Supporter](http://www.mathjax.org/#supporters).

“Becoming a MathJax Supporter is a great example for IBM's commitment to providing the science community with reliable, flexible, and open technology," comments Peter Krautzberger, MathJax manager. "It helps ensure the continuous development of MathJax and enables IBM to make optimal use of MathJax.”

The MathJax team looks forward to the collaboration with IBM, and welcomes their support for the MathJax project.
