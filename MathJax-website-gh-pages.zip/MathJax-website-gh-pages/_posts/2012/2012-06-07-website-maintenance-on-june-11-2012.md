---
layout: post
title: Website maintenance on June 11, 2012
date: 2012-06-07 11:05:50.000000000 +02:00
categories:
- News
tags: []
status: publish
type: post
published: true
meta:
  _rawhtml_settings: '0,0,0,0'
  _cws_is_markdown: '1'
  _edit_last: '12'
author:
  login: PeterK
  email: info@mathjax.org
  display_name: Peter Krautzberger
  first_name: Peter
  last_name: Krautzberger
---

Our website here at [www.mathjax.org](http://www.mathjax.org) will be down for maintenance on June 11, 2012 between 14.00-18.00 UTC.

**This maintenance will _not_ affect the MathJax CDN.**

As you may have noticed, we've had some server troubles over the last two days. We're sorry for any inconvenience this has caused. To improve the stability of our website, we are moving to a new server.

If you experience any unexpected problems, you can contact us on Twitter [@mathjax](http://twitter.com/#!/mathjax) or [our facebook page](http://www.facebook.com/pages/MathJax/351834882701).

The MathJax Team.