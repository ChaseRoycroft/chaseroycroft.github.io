---
layout: post
title: MathJax community meetup at the Joint Mathematics Meetings 2013
date: 2012-11-09 16:03:28.000000000 +01:00
categories:
- News
tags: []
status: publish
type: post
published: true
meta:
  _edit_last: '12'
  _cws_is_markdown: '1'
  _rawhtml_settings: '0,0,0,0'
  dsq_thread_id: '921228527'
author:
  login: PeterK
  email: info@mathjax.org
  display_name: Peter Krautzberger
  first_name: Peter
  last_name: Krautzberger
---

We are planning a MathJax community meetup at the [Joint Mathematics Meetings 2013](http://jointmathematicsmeetings.org/jmm) in San Diego, January 9--12, 2013.

If you're interested, please fill out [this google form](http://goo.gl/vZ2XJ) so that we can keep you updated.

See you in San Diego!

The MathJax Team.