---
layout: post
title: MathJax Meet-up at JMM in Boston
date: 2011-12-27 08:31:08.000000000 +01:00
categories:
- News
tags: []
status: publish
type: post
published: true
meta:
  _edit_last: '4'
  _rawhtml_settings: '0,0,0,0'
  dsq_thread_id: '812340098'
author:
  login: pault
  email: pault@dessci.com
  display_name: Paul Topping
  first_name: Paul
  last_name: Topping
---

We are planning some sort of informal meeting of MathJax fans at the Joint Mathematics Meetings in Boston next week. The details have not been set but we think it will be the evening of Weds. 1/4. Let us know by email or comment whether you are interested. We will also post details here as they become available.