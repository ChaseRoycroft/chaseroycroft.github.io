---
layout: post
title: The MathJax project is now accepting donations
date: 2011-06-25 03:45:57.000000000 +02:00
categories:
- Headline
- News
tags: []
status: publish
type: post
published: true
meta:
  _edit_last: '8'
  _rawhtml_settings: '0,0,0,0'
author:
  login: hylkek
  email: hkoers@gmail.com
  display_name: Hylke Koers
  first_name: Hylke
  last_name: Koers
---

We have received requests from the MathJax community to accept donations in amounts less than those required by our [Sponsorship program](http://www.mathjax.org/sponsors/mathjax-sponsorship-program/). In response we have added a Pledgie button to the MathJax home page, [www.mathjax.org](http://www.mathjax.org). Your contributions will help us continue to provide our popular CDN service, browser testing, prompt bug fixing, and new functionality and help ensure that MathJax will provide rock-solid mathematics display for your content and the enjoyment of your readers. Your help is much appreciated.