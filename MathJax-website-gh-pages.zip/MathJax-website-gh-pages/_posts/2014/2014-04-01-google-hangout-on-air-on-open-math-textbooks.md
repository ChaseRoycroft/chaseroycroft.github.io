---
layout: post
title: Google+ Hangout on Air on open math textbooks
date: 2014-04-01 01:54:31.000000000 +02:00
categories:
- COMM
- Headline
- News
- Technology
tags: []
status: publish
type: post
published: true
meta:
  _rawhtml_settings: '0,0,0,0'
  _edit_last: '13'
  _cws_is_markdown_gmt: '2014-04-01 08:54:31'
  _cws_is_markdown: '2'
  dsq_thread_id: '2571875032'
author:
  login: pkra
  email: peter.krautzberger@mathjax.org
  display_name: Peter Krautzberger
  first_name: Peter
  last_name: Krautzberger
---

Join us for a Hangout on Air with Kathi Fletcher (OERpub), David Farmer (AIM), Rob Beezer (University of Puget Sounds), Kent Morrison (Cal Poly), David Lipmman (Pierce College), and Phil Schatz (conneXions) on

**April 7, 2014, 12pm PDT / 3pm EDT / 9pm CEST / 7pm UTC.**

We'll be discussing all things open (math) textbooks -- from envisioning to authoring to delivering them to readers.

For details and updates check [the G+ event page](https://plus.google.com/u/1/b/114096530864036991751/events/cb5ecsm3f9689l9s3df6l5rbmuk).

See you next Monday!

The MathJax team.