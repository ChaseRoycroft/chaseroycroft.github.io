---
layout: post
title: Google+ Hangout on Air Q&A with Davide Cervone, Peter Jipsen, and David Lippman
date: 2014-02-14 06:05:36.000000000 +01:00
categories:
- COMM
tags:
- asciimath
- asciimathml
- David Lippman
- Davide Cervone
- hangout on air
- Peter Jipsen
status: publish
type: post
published: true
meta:
  _cws_is_markdown: '2'
  _edit_last: '13'
  _cws_is_markdown_gmt: '2014-02-21 17:09:23'
  _rawhtml_settings: '0,0,0,0'
  dsq_thread_id: '2265953080'
author:
  login: pkra
  email: peter.krautzberger@mathjax.org
  display_name: Peter Krautzberger
  first_name: Peter
  last_name: Krautzberger
---

MathJax lead developer Davide Cervone, AsciiMathML creator Peter Jipsen and AsciiMathML expert and open textbook author David Lippman are joining Peter Krautzberger for a Google+ Hangout On Air Q&amp;A next

**Friday, February 21, 2014, 9AM PST / 12pm EST / 5pm UTC.**

We're excited to answer your questions about all things MathJax and AsciiMathML, past, present and future. We'll be answering your questions using the [Q&amp;A app for hangouts](https://support.google.com/plus/answer/2660854?hl=en).

For details and updates check [the event page](https://plus.google.com/events/c9l2t1g57kkkjokh2o49701f3vg).

See you next Friday!

The MathJax team.

Update: You can [join us online right now](https://plus.google.com/u/1/b/114096530864036991751/events/cbeftt6m4pu7f2m6a41hlm555u8)