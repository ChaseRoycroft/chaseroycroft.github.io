---
layout: post
title: Atypon continues as a MathJax Supporter
date: 2014-01-21 09:15:47.000000000 +01:00
categories:
- News
tags: []
status: publish
type: post
published: true
meta:
  dsq_thread_id: '2154363968'
  _cws_is_markdown: '2'
  _cws_is_markdown_gmt: '2014-01-21 17:15:47'
  _rawhtml_settings: '0,0,0,0'
  _edit_last: '13'
author:
  login: pkra
  email: peter.krautzberger@mathjax.org
  display_name: Peter Krautzberger
  first_name: Peter
  last_name: Krautzberger
---

[Atypon](http://atypon.com) continues to support the MathJax project as a MathJax Supporter.

Atypon leverages MathJax to deliver clear and accessible mathematics on its flagship ePublishing platform [Literatum](https://www.atypon.com/products/literatum/), hosting more than 17 million journal articles, 100,000 eBooks, and many other types of scientific and scholarly content for leading publishers worldwide.

“Atypon is pleased to support MathJax through our leading digital publishing platform Literatum,” said Georgios Papadopoulos, founder and CEO of Atypon. “MathJax is the gold standard for high quality display of mathematics notation and we are excited to continue sponsoring the initiative for a second year.”

We look forward to continuing the collaboration with Atypon, and welcome their ongoing support for the MathJax project.