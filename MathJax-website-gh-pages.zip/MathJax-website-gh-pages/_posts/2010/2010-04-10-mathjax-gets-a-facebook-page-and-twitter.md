---
layout: post
title: MathJax Gets A Facebook Page (And Twitter)
date: 2010-04-10 16:25:00.000000000 +02:00
categories:
- News
tags: []
status: publish
type: post
published: true
meta:
  aktt_notify_twitter: 'no'
  _edit_last: '7'
author:
  login: caseys
  email: caseys@mathjax.org
  display_name: Casey Stark
  first_name: Casey
  last_name: Stark
---

In order to make getting news about MathJax as convenient as possible, we have created a facebook page, which we are updating regularly. You can see the page [here](http://www.facebook.com/pages/MathJax/351834882701). We have aggregated our blog and twitter feeds to automatically post to facebook whenever we update. If you like getting your news through Facebook or if you would just like to show your support for MathJax, please become a fan of our page.

If you haven't seen it yet, we would also like to announce that MathJax now has an official twitter account. You can follow our twitter @[MathJax](http://www.twitter.com/mathjax). We will be tweeting more and more as we approach the big 1.0 release, so be sure to follow us there if you want the most up-to-date news on MathJax.

You can also see all of our social media links at the top right of any page, just above the search bar.